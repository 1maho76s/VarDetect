#include "sim_mem.h"
__attribute__((annotate("shared")))int g;
struct S {int x;};

int main(){
    int x=g;    //读
    SIM_FLUSH(&(g));
    g+=1;   //复合写
    SIM_FLUSH(&(g));
    struct S s;
    s.x=g;  //读（成员)
    SIM_FLUSH(&(s.x));
    SIM_FLUSH(&(g));
    int *p =&g;     //指针来源
    SIM_FLUSH(&(g));
    *p=10;      //指针写
    SIM_FLUSH(&(*p));
    int y=*p;   //指针读
    SIM_FLUSH(&(*p));
    return g;
}
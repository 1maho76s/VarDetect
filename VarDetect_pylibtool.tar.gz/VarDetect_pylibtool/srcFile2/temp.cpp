void ase_tcp_port_check_bypass(struct ase_tcp_port *tp)
{
    struct ase_tcp_port *peer = tp->peer.psp;
    if (peer == NULL)
    { /* peer is in connecting, peer tcp port is not ready */
        ase_tcp_bypass_half_sess(tp);
        if (ase_conection_forced_detect(tp->sess_ctx->conn))
        {
            ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "fd %d ase forced but bypass", tp->se->fd);
            ase_dfx_cnt_inc(ASE_DFX_FORCE_FAIL);
        }
        return;
    }
    ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "%s check bypass pair(%d-%d) flag %d-%d ase_only %d", get_protol_str(tp), tp->se->fd, peer->se->fd, tp->waitting_bypass, ase_buf_empty(&peer->sndbuf), tp->bypass_ase_only);
    if (peer->waitting_bypass && ase_buf_empty(&peer->sndbuf))
    {
        if (ase_conection_forced_detect(tp->sess_ctx->conn))
        {
            ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "fd %d ase forced but bypass pair", tp->se->fd);
            ase_dfx_cnt_inc(ASE_DFX_FORCE_FAIL);
        }
        if (tp->bypass_ase_only)
        {
            ase_dfx_cnt_inc(ASE_DFX_BYPASS_ASE_ONLY);
            ase_sess_bypass_done(tp->caps);
            ase_sess_bypass_done(peer->caps);
            return;
        }
        bool is_transparent_proxy = ase_is_transparent_proxy(tp);
        int ret = tp->sk_ops->bypass_pair(tp->se->fd, peer->se->fd);
        if (ret < 0)
        {
            ase_dfx_cnt_inc(is_transparent_proxy ? ASE_DFX_TRANSPARENT_PROXY_BYPASS_FAILED : ASE_DFX_BYPASS_FAILED);
            ase_tcp_port_set_net_dfwd(tp, peer);
            ASE_TRACE_ERR(tp->sess_ctx, ASE_CATE_TCP_PORT, "%s port bypass fd %d--%d failed,"
                                                           " forward in socket layer",
                          get_protol_str(tp), tp->se->fd, peer->se->fd);
            return;
        }
        ase_dfx_cnt_inc(is_transparent_proxy ? ASE_DFX_TRANSPARENT_PROXY_BYPASS : ASE_DFX_BYPASS);
        ase_sess_bypass_done(tp->caps);
        ase_sess_bypass_done(peer->caps);
    }
}

void ase_tcp_port_check_bypass(struct ase_tcp_port *tp)
{
    struct ase_tcp_port *peer = tp->peer.psp;
    SIM_FLUSH(&(*peer));
    if (peer == NULL)
    { /* peer is in connecting, peer tcp port is not ready */
        ase_tcp_bypass_half_sess(tp);
        if (ase_conection_forced_detect(tp->sess_ctx->conn))
        {
            SIM_FLUSH(&(*conn));
            SIM_FLUSH(&(tp->sess_ctx));
            ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "fd %d ase forced but bypass", tp->se->fd);
            ase_dfx_cnt_inc(ASE_DFX_FORCE_FAIL);
        }
        SIM_FLUSH(&(*conn));
        SIM_FLUSH(&(*conn));
        return;
    }
    ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "%s check bypass pair(%d-%d) flag %d-%d ase_only %d", get_protol_str(tp), tp->se->fd, peer->se->fd, tp->waitting_bypass, ase_buf_empty(&peer->sndbuf), tp->bypass_ase_only);
    if (peer->waitting_bypass && ase_buf_empty(&peer->sndbuf))
    {
        if (ase_conection_forced_detect(tp->sess_ctx->conn))
        {
            SIM_FLUSH(&(*conn));
            SIM_FLUSH(&(tp->sess_ctx));
            ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "fd %d ase forced but bypass pair", tp->se->fd);
            ase_dfx_cnt_inc(ASE_DFX_FORCE_FAIL);
        }
        SIM_FLUSH(&(*conn));
        SIM_FLUSH(&(*conn));
        if (tp->bypass_ase_only)
        {
            ase_dfx_cnt_inc(ASE_DFX_BYPASS_ASE_ONLY);
            ase_sess_bypass_done(tp->caps);
            SIM_FLUSH(&(tp->caps));
            ase_sess_bypass_done(peer->caps);
            SIM_FLUSH(&(peer->caps));
            return;
        }
        SIM_FLUSH(&(tp->caps));
        bool is_transparent_proxy = ase_is_transparent_proxy(tp);
        int ret = tp->sk_ops->bypass_pair(tp->se->fd, peer->se->fd);
        SIM_FLUSH(&(tp->sk_ops));
        SIM_FLUSH(&(se->fd));
        SIM_FLUSH(&(tp->se));
        SIM_FLUSH(&(peer->se));
        if (ret < 0)
        {
            ase_dfx_cnt_inc(is_transparent_proxy ? ASE_DFX_TRANSPARENT_PROXY_BYPASS_FAILED : ASE_DFX_BYPASS_FAILED);
            ase_tcp_port_set_net_dfwd(tp, peer);
            ASE_TRACE_ERR(tp->sess_ctx, ASE_CATE_TCP_PORT, "%s port bypass fd %d--%d failed,"
                                                           " forward in socket layer",
                          get_protol_str(tp), tp->se->fd, peer->se->fd);
            return;
        }
        ase_dfx_cnt_inc(is_transparent_proxy ? ASE_DFX_TRANSPARENT_PROXY_BYPASS : ASE_DFX_BYPASS);
        ase_sess_bypass_done(tp->caps);
        SIM_FLUSH(&(tp->caps));
        ase_sess_bypass_done(peer->caps);
        SIM_FLUSH(&(peer->caps));
    }
}

static void ase_tcp_stop_flush_ntfy(struct ase_tcp_port *tp)
{
    if (tp->write_tasks.next != NULL)
    {
        sched_task_list_del(&g_tcp_port_write_task, &tp->write_tasks);
    }
}
static void ase_tcp_stop_flush_ntfy(struct ase_tcp_port *tp)
{
    if (tp->write_tasks.next != NULL)
    {
        SIM_FLUSH(&(*task));
        sched_task_list_del(&g_tcp_port_write_task, &tp->write_tasks);
    }
    SIM_FLUSH(&(*task));
}
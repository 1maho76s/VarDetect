#include "sim_mem.h"

__attribute__((annotate("shared"))) int g_global = 0;

// 保守指针示例：参数为指针，不确定指向本地还是全局
// 在 --conservative-ptr 模式下，会保守地将其视为指向全局变量
void conservativePtrDemo(int *maybe_global) {
    *maybe_global = 42;              // 指针写
    int local = *maybe_global;       // 指针读
    *maybe_global += 1;              // 指针复合写
    if (*maybe_global > 0) {         // 指针读（条件）
        local += *maybe_global;      // 指针读（表达式）
    }
}

int main() {
    g_global = 1;
    int local_var = 0;
    // 传入本地变量指针——在保守模式下仍会对 maybe_global 进行插桩
    conservativePtrDemo(&local_var);
    conservativePtrDemo(&g_global);
    return g_global;
}

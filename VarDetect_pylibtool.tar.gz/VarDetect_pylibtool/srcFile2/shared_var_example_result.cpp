#include "sim_mem.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <unistd.h>

#include "bitfield_struct.h"

#define COUNTER g_counter
#define FLAG g_flag
#define DATA g_data
#define MESSAGE g_message
#define SHARED_STATE g_shared
#define PTR g_ptr

const int g_const_value = 42;

// 全局共享变量示例
int g_counter = 0;
int g_flag = 0;
int g_data[20] = {0};  // 扩大数组大小以测试 cacheline 合并
std::string g_message = "hello";
int *g_ptr = nullptr;

struct SharedState {
    int x;           // offset 0
    double y;        // offset 8
    int z;           // offset 16
    char padding1[40]; // padding to 56
    int w;           // offset 56
    int u;           // offset 60, different cacheline (assuming 64B cacheline)
};

SharedState g_shared = {0, 0.0};

BitFieldDevice g_device = {0, 0, 0, 0, 0, 0, 0, 0};
#define DEVICE g_device

// typedef 结构体实例 — 用于测试 typedef 位域成员的插桩屏蔽
DeviceConfig g_cfg = {0, 0, 0, 0};
Sensor g_sensor = {0, 0, 0.0f};
NGE_CFGFILE_S g_ngcfg = {nullptr, nullptr, nullptr, 0, 0};

void useSharedPointer() {
    if (PTR != nullptr) {
        SIM_FLUSH(&(g_ptr));
        *PTR += 1;
        SIM_FLUSH(&(*g_ptr));
        DATA[1] = *PTR;
        SIM_FLUSH(&(g_data[0]));
        SIM_FLUSH(&(*g_ptr));
    }
}

void updateMessage() {
    if (FLAG == 1) {
        SIM_FLUSH(&(g_flag));
        MESSAGE += "_updated";
        SIM_FLUSH(&(g_message));
    } else {
        SIM_FLUSH(&(g_flag));
        MESSAGE = "waiting";
        SIM_FLUSH(&(g_message));
    }
}

void *workerA(void *arg) {
    (void)arg;
    for (int i = 0; i < 100; ++i) {
        COUNTER += 1;
        SIM_FLUSH(&(g_counter));
        FLAG = (COUNTER % 2);
        SIM_FLUSH(&(g_flag));
        SIM_FLUSH(&(g_counter));
        SHARED_STATE.x = COUNTER;
        SIM_FLUSH(&(SHARED_STATE.x));
        SIM_FLUSH(&(g_counter));
        SHARED_STATE.y = SHARED_STATE.x * 0.5;
        SIM_FLUSH(&(SHARED_STATE.y));
        SHARED_STATE.z = SHARED_STATE.x + 10;
        SIM_FLUSH(&(SHARED_STATE.z));
        SHARED_STATE.w = SHARED_STATE.x * 2;  // Different cacheline
        SIM_FLUSH(&(SHARED_STATE.w));
        SHARED_STATE.u = COUNTER;             // Different cacheline
        SIM_FLUSH(&(SHARED_STATE.u));
        SIM_FLUSH(&(g_counter));
        if (COUNTER % 10 == 0) {
            SIM_FLUSH(&(g_counter));
            DATA[0] = COUNTER;
            SIM_FLUSH(&(g_data[0]));
            SIM_FLUSH(&(g_counter));
            DATA[17] = COUNTER + 1;  // 添加对不同 cacheline 的访问
            SIM_FLUSH(&(g_data[16]));
            SIM_FLUSH(&(g_counter));
        }
        useSharedPointer();
        updateMessage();
        usleep(1000);
    }
    return nullptr;
}

void *workerB(void *arg) {
    (void)arg;
    for (int i = 0; i < 80; ++i) {
        if (FLAG) {
            SIM_FLUSH(&(g_flag));
            DATA[2] = COUNTER;
            SIM_FLUSH(&(g_data[0]));
            SIM_FLUSH(&(g_counter));
        }
        DATA[3] = SHARED_STATE.x + i;
        SIM_FLUSH(&(g_data[0]));
        SIM_FLUSH(&(SHARED_STATE.x));
        FLAG = (DATA[3] % 2);
        SIM_FLUSH(&(g_flag));
        SIM_FLUSH(&(g_data[0]));
        if (PTR) {
            SIM_FLUSH(&(g_ptr));
            *PTR = DATA[3];
            SIM_FLUSH(&(*g_ptr));
            SIM_FLUSH(&(g_data[0]));
        }
        updateMessage();
        usleep(1500);
    }
    return nullptr;
}

void helperFunction() {
    if (DATA[0] > 0) {
        SIM_FLUSH(&(g_data[0]));
        DATA[1] = DATA[0] + DATA[2];
        SIM_FLUSH(&(g_data[0]));
    }
    MESSAGE += ":done";
    SIM_FLUSH(&(g_message));
    SHARED_STATE.x = DATA[1];
    SIM_FLUSH(&(SHARED_STATE.x));
    SIM_FLUSH(&(g_data[0]));
    int local_sum = SHARED_STATE.x + g_const_value;
    SIM_FLUSH(&(SHARED_STATE.x));
    MESSAGE += std::to_string(local_sum);
    SIM_FLUSH(&(g_message));
    // 位域结构体访问
    DEVICE.status = 3;
    DEVICE.channel = DATA[1];
    SIM_FLUSH(&(g_data[0]));
    if (DEVICE.enabled) {
        DEVICE.flags |= 0x01;
    }
    // typedef 位域结构体访问
    g_cfg.a = 1;            // 位域（应跳过）
    g_cfg.b = DEVICE.mode;  // 位域（应跳过）
    g_cfg.b = DATA[1];          // 普通字段（应插桩）
    SIM_FLUSH(&(g_data[0]));
    g_cfg.c = 100;          // 普通字段（应插桩）
    SIM_FLUSH(&(g_cfg.c));
    g_sensor.id = 5;        // 位域（应跳过）
    g_sensor.active = 1;    // 位域（应跳过）
    g_sensor.value = 3.14f; // 普通字段（应插桩）
    SIM_FLUSH(&(g_sensor.value));
    // 多声明式位域测试（一行多个位域成员）
    g_ngcfg.uiParseState = 1;
    g_ngcfg.uiIsNeedCheck = 0;
    g_ngcfg.uiReserve = 0;
    g_ngcfg.pcKeyEn = nullptr;
    SIM_FLUSH(&(g_ngcfg.pcKeyEn));
}

void startThreadWork() {
    pthread_t t1, t2;
    int value = 10;
    PTR = &value;
    SIM_FLUSH(&(g_ptr));

    if (pthread_create(&t1, nullptr, workerA, nullptr) != 0) {
        perror("pthread_create workerA");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&t2, nullptr, workerB, nullptr) != 0) {
        perror("pthread_create workerB");
        exit(EXIT_FAILURE);
    }

    if (pthread_join(t1, nullptr) != 0) {
        perror("pthread_join t1");
        exit(EXIT_FAILURE);
    }
    if (pthread_join(t2, nullptr) != 0) {
        perror("pthread_join t2");
        exit(EXIT_FAILURE);
    }
}

int main() {
    PTR = new int(5);
    SIM_FLUSH(&(g_ptr));
    MESSAGE = "start";
    SIM_FLUSH(&(g_message));
    startThreadWork();
    helperFunction();

    printf("g_const_value=%d g_counter=%d g_flag=%d g_data=[%d,%d,%d,%d] g_message=%s g_shared={%d,%.1f}\n",
           g_const_value, COUNTER, FLAG,
           DATA[0], DATA[1], DATA[2], DATA[3],
           MESSAGE.c_str(), SHARED_STATE.x, SHARED_STATE.y);
    SIM_FLUSH(&(g_counter));
    SIM_FLUSH(&(g_flag));
    SIM_FLUSH(&(g_data[0]));
    SIM_FLUSH(&(g_message));
    SIM_FLUSH(&(SHARED_STATE.y));
    delete PTR;
    SIM_FLUSH(&(g_ptr));
    return 0;
}

// 保守指针示例：仅在 --conservative-ptr 模式下会对 maybe_global 进行插桩
void conservativePtrDemo(int *maybe_global) {
    *maybe_global = 42;
    SIM_FLUSH(&(*maybe_global));
    int local = *maybe_global;
    SIM_FLUSH(&(*maybe_global));
    *maybe_global += 1;
    SIM_FLUSH(&(*maybe_global));
    if (*maybe_global > 0) {
        SIM_FLUSH(&(*maybe_global));
        local += *maybe_global;
        SIM_FLUSH(&(*maybe_global));
    }
    if (*maybe_global < 0) 
    {
        SIM_FLUSH(&(*maybe_global));
        local += *maybe_global;
        SIM_FLUSH(&(*maybe_global));
    }
    else if (*maybe_global == 0)
    {
        SIM_FLUSH(&(*maybe_global));
        local = 0;
    }
    else if (*maybe_global > 100) {
        SIM_FLUSH(&(*maybe_global));
        local = 100;
    } else
    {
        SIM_FLUSH(&(*maybe_global));
        local -= *maybe_global;
        SIM_FLUSH(&(*maybe_global));
    }
}
#include "sim_mem.h"
__attribute__((annotate("shared")))int g;
struct S {int x;};

int main(){
    int x=g;    //读
    g+=1;   //复合写
    struct S s;
    s.x=g;  //读（成员)
    int *p =&g;     //指针来源
    *p=10;      //指针写
    int y=*p;   //指针读
    return g;
}
#include "sim_mem.h"
/* * Copyright (c) Huawei Technologies Co., Ltd. 2021-2021. All rights reserved. * Description: 协议栈epoll适配 * Author: yujianwei 00302363 * Create: 2021-06-03 */
#include "hps_epoll_adp.h"
#include <stdlib.h>
#include <inttypes.h>
#include <string.h>
#include <unistd.h>
#include <sys/epoll.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <errno.h>
#ifndef __STDIN__
#include "hpp-hps-dap/socket.h"
#endif
#include "ase_tcp_port.h"
#include "Sensor.h"
#include "DeviceConfig.h"
#include "ase_stdlib.h"
#include "ase_rtcm.h"
#include "securec.h"
#include "ase_module.h"
#include "ase_std.h"
#include "ase_debug.h"
#include "ase_diag_log.h"
#include "ase_timer.h"
#include "sched_evt.h"
#include "sched_task.h"
#include "hps_sock_adp.h"
#include "proc_index.h"
#include "ase_diag_log.h"
#include "ase_rtcm.h"
#include "hps_sock_adp.h"
#ifdef __cplusplus
#if __cplusplus
extern "C"
{
#endif
#endif
    uint32_t g_hps_epoll_dry_run_times = 0;
    uint64_t g_hps_epoll_cycle_per_ms = 0;
    struct hps_epl_ops
    {
        void *handle;
        int mode;
        /* HPS_NORMAL_MODE/HPS_SPECIAL_MODE */ int (*create)(int size);
        int (*create_special)(int size, char *name, int *nv_fd);
        int (*ctl)(int epfd, int op, int fd, struct epoll_event *event);
        int (*wait)(int epfd, struct epoll_event *events, int maxEvents, int timeout);
        int (*close)(int fd);
        int (*close_special)(int fd);
        int (*init_sched)();
    };
    struct hps_epl_ops g_hps_epl_ops;
#define HPS_SCHED_EVTS_MAX 256
    struct hps_epoll_ctx
    {
        int ep_fd;
        int nv_fd;
        struct sched_epl hps_base;
        struct sched_evt *se;
        struct epoll_event evts[HPS_SCHED_EVTS_MAX];
    };
    struct hps_epoll_ctx g_hps_epoll_ctx;
    static tcp_flush_all_data_f g_hps_tcp_flush_all_data;
    static void hps_mod_clean() {}
    void hps_mod_close()
    { /* epfd 不能在clean 里调用,因为,clean的时候,可能还有会话需要close 需要调用到这里加载的epoll 的接口 */
        if (g_hps_epl_ops.handle == NULL)
        {
            SIM_FLUSH(&(g_hps_epl_ops.handle));
            return;
        }
        SIM_FLUSH(&(g_hps_epl_ops.handle));
        const struct sched_epl *sched_epl = sched_epl_get(SCHED_EPL_HPS);
        if (sched_epl->epfd != -1)
        { /* nvfd will be closed with epfd if have nvfd */
        }
        struct sched_epl hps_sched_epl = {
            .type = SCHED_EPL_HPS,
            .epfd = -1,
            .evt_cnt = 1,
            .base = NULL,
            .epfd_close = NULL,
            .fd_close = NULL,
            .ep_ctl = NULL,
        };
        sched_epl_set(SCHED_EPL_HPS, &hps_sched_epl);
        if (g_hps_epoll_ctx.se != NULL)
        {
            SIM_FLUSH(&(g_hps_epoll_ctx.se));
            sched_evt_put(g_hps_epoll_ctx.se);
            SIM_FLUSH(&(g_hps_epoll_ctx.se));
        }
        SIM_FLUSH(&(g_hps_epoll_ctx.se));
        if (g_hps_epl_ops.handle != NULL)
        {
            SIM_FLUSH(&(g_hps_epl_ops.handle));
            dlclose(g_hps_epl_ops.handle);
            SIM_FLUSH(&(g_hps_epl_ops.handle));
            g_hps_epl_ops.handle = NULL;
            SIM_FLUSH(&(g_hps_epl_ops.handle));
        }
        SIM_FLUSH(&(g_hps_epl_ops.handle));
    }
#ifdef __nohcfi
#define NO_HCFI __nohcfi
#else
#define NO_HCFI
#endif
#define HPS_NSTACK_SO_NAME "libnsocket.so"
    NO_HCFI int32_t load_hps_special_epoll_ops(void *handle)
    {
        g_hps_epl_ops.create = dlsym(handle, "HPS_EpollCreate");
        SIM_FLUSH(&(g_hps_epl_ops.create));
        if (!g_hps_epl_ops.create)
        {
            SIM_FLUSH(&(g_hps_epl_ops.create));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollCreate failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.create));
        g_hps_epl_ops.create_special = dlsym(handle, "HPS_EpollCreateSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.create_special));
        if (!g_hps_epl_ops.create_special)
        {
            SIM_FLUSH(&(g_hps_epl_ops.create_special));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollCreate failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.create_special));
        g_hps_epl_ops.ctl = dlsym(handle, "HPS_EpollCtlSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.ctl));
        if (!g_hps_epl_ops.ctl)
        {
            SIM_FLUSH(&(g_hps_epl_ops.ctl));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollCtl failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.ctl));
        g_hps_epl_ops.wait = dlsym(handle, "HPS_EpollWaitSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.wait));
        if (!g_hps_epl_ops.wait)
        {
            SIM_FLUSH(&(g_hps_epl_ops.wait));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollWait failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.wait));
        g_hps_epl_ops.close = dlsym(handle, "HPS_CloseSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.close));
        if (!g_hps_epl_ops.close)
        {
            SIM_FLUSH(&(g_hps_epl_ops.close));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_Close failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.close));
        g_hps_epl_ops.close_special = dlsym(handle, "HPS_CloseSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.close_special));
        if (!g_hps_epl_ops.close_special)
        {
            SIM_FLUSH(&(g_hps_epl_ops.close_special));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_Close failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.close_special));
        return 0;
    dlsym_fail:
        return -1;
    }
    NO_HCFI int32_t load_hps_normal_epoll_ops(void *handle)
    {
        g_hps_epl_ops.create = dlsym(handle, "HPS_EpollCreate");
        SIM_FLUSH(&(g_hps_epl_ops.create));
        if (!g_hps_epl_ops.create)
        {
            SIM_FLUSH(&(g_hps_epl_ops.create));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollCreate failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.create));
        g_hps_epl_ops.create_special = dlsym(handle, "HPS_EpollCreateSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.create_special));
        if (!g_hps_epl_ops.create_special)
        {
            SIM_FLUSH(&(g_hps_epl_ops.create_special));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollCreate failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.create_special));
        g_hps_epl_ops.ctl = dlsym(handle, "HPS_EpollCtl");
        SIM_FLUSH(&(g_hps_epl_ops.ctl));
        if (!g_hps_epl_ops.ctl)
        {
            SIM_FLUSH(&(g_hps_epl_ops.ctl));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollCtl failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.ctl));
        g_hps_epl_ops.wait = dlsym(handle, "HPS_EpollWait");
        SIM_FLUSH(&(g_hps_epl_ops.wait));
        if (!g_hps_epl_ops.wait)
        {
            SIM_FLUSH(&(g_hps_epl_ops.wait));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_EpollWait failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.wait));
        g_hps_epl_ops.close = dlsym(handle, "HPS_Close");
        SIM_FLUSH(&(g_hps_epl_ops.close));
        if (!g_hps_epl_ops.close)
        {
            SIM_FLUSH(&(g_hps_epl_ops.close));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_Close failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.close));
        g_hps_epl_ops.close_special = dlsym(handle, "HPS_CloseSpecial");
        SIM_FLUSH(&(g_hps_epl_ops.close_special));
        if (!g_hps_epl_ops.close_special)
        {
            SIM_FLUSH(&(g_hps_epl_ops.close_special));
            ASE_DIAG_LOG_WITH_JOURNAL("hps epoll dlsym HPS_Close failed %s.", dlerror());
            goto dlsym_fail;
        }
        SIM_FLUSH(&(g_hps_epl_ops.close_special));
        return 0;
    dlsym_fail:
        return -1;
    }
    static int hps_so_dlopen()
    {
        if (g_hps_epl_ops.handle != NULL)
        {
            SIM_FLUSH(&(g_hps_epl_ops.handle));
            return 0;
        }
        SIM_FLUSH(&(g_hps_epl_ops.handle));
        g_hps_epl_ops.handle = dlopen(HPS_NSTACK_SO_NAME, RTLD_NOW);
        SIM_FLUSH(&(g_hps_epl_ops.handle));
        if (g_hps_epl_ops.handle == NULL)
        {
            SIM_FLUSH(&(g_hps_epl_ops.handle));
            ASE_DIAG_LOG_WITH_JOURNAL("hps nsocket dlopen %s failed %s.", HPS_NSTACK_SO_NAME, dlerror());
            return -1;
        }
        SIM_FLUSH(&(g_hps_epl_ops.handle));
        return 0;
    }
    /* 进程初始化加载库 */
    void hps_so_load(enum hps_mode mode)
    {
        if (hps_so_dlopen() != 0)
        {
            return;
        }
        g_hps_epl_ops.mode = mode;
        if (mode == HPS_NORMAL_MODE)
        {
            if (load_hps_normal_epoll_ops(g_hps_epl_ops.handle) != 0)
            {
                SIM_FLUSH(&(g_hps_epl_ops.handle));
                goto dlsym_fail;
            }
            SIM_FLUSH(&(g_hps_epl_ops.handle));
        SIM_FLUSH(&(g_hps_epl_ops.handle));
            hps_load_normal_sock_ops(g_hps_epl_ops.handle);
            SIM_FLUSH(&(g_hps_epl_ops.handle));
        }
        else
        {
            if (load_hps_special_epoll_ops(g_hps_epl_ops.handle) != 0)
            {
                SIM_FLUSH(&(g_hps_epl_ops.handle));
                goto dlsym_fail;
            }
            SIM_FLUSH(&(g_hps_epl_ops.handle));
            hps_load_special_sock_ops(g_hps_epl_ops.handle);
            SIM_FLUSH(&(g_hps_epl_ops.handle));
        }
        return;
    dlsym_fail:
        dlclose(g_hps_epl_ops.handle);
        SIM_FLUSH(&(g_hps_epl_ops.handle));
        g_hps_epl_ops.handle = NULL; /* 库加载不上需要正常往下走,可以不带hps跑 */
        SIM_FLUSH(&(g_hps_epl_ops.handle));
        ASE_DIAG_LOG_WITH_JOURNAL("hps epoll lib load fail.");
    }
    void hps_set_tcp_flush_func(tcp_flush_all_data_f func)
    {
        g_hps_tcp_flush_all_data = func;
        SIM_FLUSH(&(g_hps_tcp_flush_all_data));
    }
    void hps_tcp_flush_all_data()
    {
        if (g_hps_tcp_flush_all_data != NULL)
        {
            SIM_FLUSH(&(g_hps_tcp_flush_all_data));
            g_hps_tcp_flush_all_data();
            SIM_FLUSH(&(g_hps_tcp_flush_all_data));
        }
        SIM_FLUSH(&(g_hps_tcp_flush_all_data));
    }
    static enum sched_evt_types hps_convert_evts(const struct epoll_event *ee)
    {
        uint32_t sch_evts = 0;
        if (ee->events & EPOLLIN)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_READ;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLLOUT)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_WRITE;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLLRDHUP)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_RDHUP;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLLHUP)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_HUP;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLLERR)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_ERROR;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLLET)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_ET;
        }
        SIM_FLUSH(&(ee->events));
#ifndef __STDIN__
        if (ee->events & EPOLL_ASW_SUCC)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_SWITCH_PROXY_DONE;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLL_ASW_FAIL)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_SWITCH_PROXY_FAIL;
        }
        SIM_FLUSH(&(ee->events));
        if (ee->events & EPOLL_BYPASS)
        {
            SIM_FLUSH(&(ee->events));
            sch_evts |= SCHED_EVT_BYPASS;
        }
        SIM_FLUSH(&(ee->events));
#endif
        return (enum sched_evt_types)sch_evts;
    }
}


static void ase_tcp_stop_flush_ntfy(struct ase_tcp_port *tp)
{
    if (tp->write_tasks.next != NULL)
    {
        SIM_FLUSH(&(tp->write_tasks));
        sched_task_list_del(&g_tcp_port_write_task, &tp->write_tasks);
    }
    SIM_FLUSH(&(tp->write_tasks));
}

void ase_tcp_port_check_bypass(struct ase_tcp_port *tp)
{
    struct ase_tcp_port *peer = tp->peer.psp;
    SIM_FLUSH(&(tp->peer));
    if (peer == NULL)
    { /* peer is in connecting, peer tcp port is not ready */
        ase_tcp_bypass_half_sess(tp);
        if (ase_conection_forced_detect(tp->sess_ctx->conn))
        {
            SIM_FLUSH(&(tp->sess_ctx));
            SIM_FLUSH(&(tp->sess_ctx->conn));
            ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "fd %d ase forced but bypass", tp->se->fd);
            ase_dfx_cnt_inc(ASE_DFX_FORCE_FAIL);
        }
        SIM_FLUSH(&(tp->sess_ctx));
        return;
    }
    ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "%s check bypass pair(%d-%d) flag %d-%d ase_only %d", get_protol_str(tp), tp->se->fd, peer->se->fd, tp->waitting_bypass, ase_buf_empty(&peer->sndbuf), tp->bypass_ase_only);
    if (peer->waitting_bypass && ase_buf_empty(&peer->sndbuf))
    {
        SIM_FLUSH(&(peer->waitting_bypass));
        if (ase_conection_forced_detect(tp->sess_ctx->conn))
        {
            SIM_FLUSH(&(tp->sess_ctx));
            SIM_FLUSH(&(tp->sess_ctx->conn));
            ASE_TRACE_INFO(tp->sess_ctx, ASE_CATE_TCP_PORT, "fd %d ase forced but bypass pair", tp->se->fd);
            ase_dfx_cnt_inc(ASE_DFX_FORCE_FAIL);
        }
        SIM_FLUSH(&(tp->sess_ctx));
        if (tp->bypass_ase_only)
        {
            ase_dfx_cnt_inc(ASE_DFX_BYPASS_ASE_ONLY);
            ase_sess_bypass_done(tp->caps);
            SIM_FLUSH(&(tp->caps));
            SIM_FLUSH(&(tp->caps));
            ase_sess_bypass_done(peer->caps);
            SIM_FLUSH(&(peer->caps));
            SIM_FLUSH(&(peer->caps));
            return;
        }
        SIM_FLUSH(&(tp->caps));
        bool is_transparent_proxy = ase_is_transparent_proxy(tp);
        int ret = tp->sk_ops->bypass_pair(tp->se->fd, peer->se->fd);
        SIM_FLUSH(&(tp->sk_ops));
        SIM_FLUSH(&(tp->sk_ops->bypass_pair));
        SIM_FLUSH(&(tp->se));
        SIM_FLUSH(&(tp->se->fd));
        SIM_FLUSH(&(peer->se));
        SIM_FLUSH(&(peer->se->fd));
        if (ret < 0)
        {
            ase_dfx_cnt_inc(is_transparent_proxy ? ASE_DFX_TRANSPARENT_PROXY_BYPASS_FAILED : ASE_DFX_BYPASS_FAILED);
            ase_tcp_port_set_net_dfwd(tp, peer);
            ASE_TRACE_ERR(tp->sess_ctx, ASE_CATE_TCP_PORT, "%s port bypass fd %d--%d failed,"
                                                           " forward in socket layer",
                          get_protol_str(tp), tp->se->fd, peer->se->fd);
            return;
        }
        ase_dfx_cnt_inc(is_transparent_proxy ? ASE_DFX_TRANSPARENT_PROXY_BYPASS : ASE_DFX_BYPASS);
        ase_sess_bypass_done(tp->caps);
        SIM_FLUSH(&(tp->caps));
        SIM_FLUSH(&(tp->caps));
        ase_sess_bypass_done(peer->caps);
        SIM_FLUSH(&(peer->caps));
        SIM_FLUSH(&(peer->caps));
    }
    SIM_FLUSH(&(peer->waitting_bypass));
}
import tempfile
import unittest
from pathlib import Path

from sharedvarfinder.finder import find_shared_variables, find_shared_variables_in_text


class TestFinder(unittest.TestCase):
    def test_find_shared_variables_in_text(self):
        source = '''
            #include <stdio.h>
            int global_count = 0;
            static float shared_temp;
            extern char *message;
            namespace foo {
                static int namespace_flag = 1;
            }
            void foo() {
                int local_value = 2;
            }
        '''

        variables = find_shared_variables_in_text(source, "test.cpp")
        names = {var.name for var in variables}

        self.assertIn("global_count", names)
        self.assertIn("shared_temp", names)
        self.assertIn("message", names)
        self.assertIn("namespace_flag", names)
        self.assertEqual({var.kind for var in variables}, {"global", "static", "extern"})

    def test_find_shared_variables_in_file(self):
        source = '''
            int global_count = 0;
            static float shared_temp;
            extern char *message;
            namespace foo { static int namespace_flag = 1; }
            void foo() { int local_value = 2; }
        '''

        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "test.cpp"
            path.write_text(source, encoding="utf-8")
            variables = find_shared_variables([str(path)])
            names = {var.name for var in variables}

            self.assertIn("global_count", names)
            self.assertIn("shared_temp", names)
            self.assertIn("message", names)
            self.assertIn("namespace_flag", names)
            self.assertEqual({var.kind for var in variables}, {"global", "static", "extern"})


if __name__ == "__main__":
    unittest.main()

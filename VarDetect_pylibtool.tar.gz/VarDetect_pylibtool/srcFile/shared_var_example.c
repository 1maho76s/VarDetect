#define _DEFAULT_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>

#include "ase_tcp_port.h"
// #include "ase_debug.h"
// #include "ase_mem.h"
// #include "ase_pmem.h"
// #include "ase_mmem.h"
// #include "sched_task.h"
// #include "sched_list.h"
// #include "ase_str.h"
// #include "ase_io.h"
// #include "ase_dlt_factory.h"
// #include "ase_buf.h"
// #include "ase_sock.h"
// #include "ase_port_factory.h"
// #include "ase_aging.h"
// #include "ase_net_port.h"
// #include "ase_stat.h"
// #include "ase_sess_status.h"
// #include "ase_tcp_port_sock_ops.h"
// #include "ase_framework_builder.h"
// #include "ase_client.h"
// #include "ase_dbg_trace.h"
// #include "ase_connection_id.h"
// #include "ase_sys_dfx_frame.h"
// #include "ase_sys_dfx_traffic.h"
// #include "ase_timer_list.h"
// #include "ase_perf_analyse.h"
// #include "ase_forward_cfg.h"
// #include "ase_mbuf_monitor.h"
// #include "ase_pfd.h"
// #include "ase_rtcm.h"
// #include "ase_perf_session.h"
// #include "ase_tproxy_str.h"
// #include "ase_frame_kpi.h"

#include "bitfield_struct.h"

#define COUNTER g_counter
#define FLAG g_flag
#define DATA g_data
#define MESSAGE g_message
#define SHARED_STATE g_shared
#define PTR g_ptr

const int g_const_value = 42;

// 全局共享变量示例
int g_counter = 0;
int g_flag = 0;
int g_data[20] = {0};  // 扩大数组大小以测试 cacheline 合并
char g_message[256] = "hello";
int *g_ptr = NULL;

struct SharedState {
    int x;           // offset 0
    double y;        // offset 8
    int z;           // offset 16
    char padding1[40]; // padding to 56
    int w;           // offset 56
    int u;           // offset 60, different cacheline (assuming 64B cacheline)
};

struct SharedState g_shared = {0, 0.0};

struct BitFieldDevice g_device = {0, 0, 0, 0, 0, 0, 0, 0};
#define DEVICE g_device

// typedef 结构体实例 — 用于测试 typedef 位域成员的插桩屏蔽
DeviceConfig g_cfg = {0, 0, 0, 0};
Sensor g_sensor = {0, 0, 0.0f};
NGE_CFGFILE_S g_ngcfg = {NULL, NULL, NULL, 0, 0};

void useSharedPointer() {
    if (PTR != NULL) {
        *PTR += 1;
        DATA[1] = *PTR;
    }
}

void updateMessage() {
    if (FLAG == 1) {
        strcat(MESSAGE, "_updated");
    } else {
        strcpy(MESSAGE, "waiting");
    }
}

void *workerA(void *arg) {
    (void)arg;
    for (int i = 0; i < 100; ++i) {
        COUNTER += 1;
        FLAG = (COUNTER % 2);
        SHARED_STATE.x = COUNTER;
        SHARED_STATE.y = SHARED_STATE.x * 0.5;
        SHARED_STATE.z = SHARED_STATE.x + 10;
        SHARED_STATE.w = SHARED_STATE.x * 2;  // Different cacheline
        SHARED_STATE.u = COUNTER;             // Different cacheline
        if (COUNTER % 10 == 0) {
            DATA[0] = COUNTER;
            DATA[17] = COUNTER + 1;  // 添加对不同 cacheline 的访问
        }
        useSharedPointer();
        updateMessage();
        usleep(1000);
    }
    return NULL;
}

void *workerB(void *arg) {
    (void)arg;
    for (int i = 0; i < 80; ++i) {
        if (FLAG) {
            DATA[2] = COUNTER;
        }
        DATA[3] = SHARED_STATE.x + i;
        FLAG = (DATA[3] % 2);
        if (PTR) {
            *PTR = DATA[3];
        }
        updateMessage();
        usleep(1500);
    }
    return NULL;
}

void helperFunction() {
    if (DATA[0] > 0) {
        DATA[1] = DATA[0] + DATA[2];
    }
    strcat(MESSAGE, ":done");
    SHARED_STATE.x = DATA[1];
    int local_sum = SHARED_STATE.x + g_const_value;
    char buf[32];
    snprintf(buf, sizeof(buf), "%d", local_sum);
    strcat(MESSAGE, buf);
    // 位域结构体访问
    DEVICE.status = 3;
    DEVICE.channel = DATA[1];
    if (DEVICE.enabled) {
        DEVICE.flags |= 0x01;
    }
    // typedef 位域结构体访问
    g_cfg.a = 1;            // 位域（应跳过）
    g_cfg.b = DEVICE.mode;  // 位域（应跳过）
    g_cfg.b = DATA[1];          // 普通字段（应插桩）
    g_cfg.c = 100;          // 普通字段（应插桩）
    g_sensor.id = 5;        // 位域（应跳过）
    g_sensor.active = 1;    // 位域（应跳过）
    g_sensor.value = 3.14f; // 普通字段（应插桩）
    // 多声明式位域测试（一行多个位域成员）
    g_ngcfg.uiParseState = 1;
    g_ngcfg.uiIsNeedCheck = 0;
    g_ngcfg.uiReserve = 0;
    g_ngcfg.pcKeyEn = NULL;
}

void startThreadWork() {
    pthread_t t1, t2;
    int value = 10;
    PTR = &value;

    if (pthread_create(&t1, NULL, workerA, NULL) != 0) {
        perror("pthread_create workerA");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&t2, NULL, workerB, NULL) != 0) {
        perror("pthread_create workerB");
        exit(EXIT_FAILURE);
    }

    if (pthread_join(t1, NULL) != 0) {
        perror("pthread_join t1");
        exit(EXIT_FAILURE);
    }
    if (pthread_join(t2, NULL) != 0) {
        perror("pthread_join t2");
        exit(EXIT_FAILURE);
    }
}

int main() {
    PTR = malloc(sizeof(int));
    *PTR = 5;
    strcpy(MESSAGE, "start");
    startThreadWork();
    helperFunction();

    printf("g_const_value=%d g_counter=%d g_flag=%d g_data=[%d,%d,%d,%d] g_message=%s g_shared={%d,%.1f}\n",
           g_const_value, COUNTER, FLAG,
           DATA[0], DATA[1], DATA[2], DATA[3],
           MESSAGE, SHARED_STATE.x, SHARED_STATE.y);
    free(PTR);
    return 0;
}

// 保守指针示例：仅在 --conservative-ptr 模式下会对 maybe_global 进行插桩
void conservativePtrDemo(int *maybe_global) {
    *maybe_global = 42;
    int local = *maybe_global;
    *maybe_global += 1;
    if (*maybe_global > 0) {
        local += *maybe_global;
    }
    if (*maybe_global < 0) 
        local += *maybe_global;
    else if (*maybe_global == 0)
        local = 0;
    else if (*maybe_global > 100) {
        local = 100;
    } else
        local -= *maybe_global;
}
